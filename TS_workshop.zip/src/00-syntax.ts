/**
 * Type annotation/defintion syntax
 * using ':' token
 */

// let someVariable: boolean;
//     ~~~~~~~~~~~~  ~~~~~~~
//     variable    : type

let someJsVar = false; // JavaScript boolean

let someVariable: boolean = false; // TypeScript boolean;
